import React from 'react';
import { motion } from 'framer-motion';

const YouTubeVideos: React.FC = () => {
  // Replace with your actual YouTube video data
  const videos = [
    {
      id: 'dQw4w9WgXcQ', // Replace with actual video ID
      title: 'Amazing Product Tutorial',
      description: 'Learn how to use our product with this step-by-step tutorial.',
    },
    {
      id: 'tVj0ZTS4WF4', // Replace with actual video ID
      title: 'Customer Testimonials',
      description: 'Hear from our satisfied customers about their experiences.',
    },
    {
      id: 'L_jITXt4eqE', // Replace with actual video ID
      title: 'Innovative Design Showcase',
      description: 'Explore our latest designs and innovations in this short video.',
    },
  ];

  return (
    <section className="py-20 bg-gray-100 text-gray-900">
      <div className="container mx-auto px-6">
        <motion.h2
          className="text-5xl font-bold mb-12 text-center bg-clip-text text-transparent bg-gradient-to-r from-purple-500 to-indigo-600"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          Watch Our Videos
        </motion.h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {videos.map((video, index) => (
            <motion.div
              key={index}
              className="bg-white p-4 rounded-lg shadow-lg"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.2 }}
            >
              <div className="relative w-full pb-56.25%">
                <iframe
                  className="absolute top-0 left-0 w-full h-full rounded-lg"
                  src={`https://www.youtube.com/embed/${video.id}`}
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                  title={video.title}
                ></iframe>
              </div>
              <h3 className="text-xl font-semibold mt-4">{video.title}</h3>
              <p className="text-gray-600 mt-2">{video.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default YouTubeVideos;
