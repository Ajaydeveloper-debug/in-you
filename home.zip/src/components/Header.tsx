import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

import '../App.css'

const Header: React.FC = () => {
  return (
    <header className="bg-gradient-to-r from-gray-900 via-gray-700 to-gray-900 text-white p-4 flex justify-between items-center shadow-lg">
      {/* Logo or Brand Name */}
      <div className="text-lg font-bold flex items-center space-x-2">
        <img src="/path/to/logo.png" alt="Logo" className="w-12 h-12" /> {/* Replace with your logo path */}
        <span>Modern Design & Washlets</span>
      </div>

      {/* Navigation */}
      <nav className="space-x-10">
        <motion.div
          className="inline-block"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <Link to="/" className="hover:text-gray-300 transition-colors duration-300">Home</Link>
        </motion.div>
        <motion.div
          className="inline-block"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6 }}
        >
          <Link to="/about" className="hover:text-gray-300 transition-colors duration-300">About</Link>
        </motion.div>
        <motion.div
          className="inline-block"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.7 }}
        >
          <Link to="/team" className="hover:text-gray-300 transition-colors duration-300">Team</Link>
        </motion.div>
        <motion.div
          className="inline-block"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8 }}
        >
          <Link to="/products" className="hover:text-gray-300 transition-colors duration-300">Products</Link>
        </motion.div>
        <motion.div
          className="inline-block"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.9 }}
        >
          <Link to="/architectural-designs" className="hover:text-gray-300 transition-colors duration-300">Architectural Designs</Link>
        </motion.div>
        <motion.div
          className="inline-block"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1 }}
        >
          <Link to="/contact" className="hover:text-gray-300 transition-colors duration-300">Contact</Link>
        </motion.div>
      </nav>
    </header>
  );
};

export default Header;
