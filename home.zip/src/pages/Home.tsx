



import { useState } from 'react'
import { Dialog, DialogPanel } from '@headlessui/react'
import { Bars3Icon, XMarkIcon } from '@heroicons/react/24/outline'
import { LockClosedIcon, ServerIcon,FingerPrintIcon , HomeModernIcon, LightBulbIcon, CalendarIcon} from '@heroicons/react/20/solid'
import Slider from 'react-slick';
import "slick-carousel/slick/slick.css"; 
import "slick-carousel/slick/slick-theme.css";
import productImage from '../assets/images/2149385431.jpg';
import productImage1 from '../assets/images/2149385433.jpg';
import productImage2 from '../assets/images/2149385439.jpg';
import Logo from '../assets/images/ダウンロード-removebg-preview.png';



import HeroVideoDialog from '../components/Hero';
import Footer1 from '../components/Footer'



const navigation = [
  { name: 'Home', href: '/' },

  { name: 'About', href: '/About' },
  { name: 'Our Products', href: '/Product' },
  { name: 'Architecture designs', href: '#' },
  { name: 'Contact', href: '#' },
]

const features = [
    {
      name: 'Push to deploy.',
      description:
        'Lorem ipsum, dolor sit amet consectetur adipisicing elit. Maiores impedit perferendis suscipit eaque, iste dolor cupiditate blanditiis ratione.',
        icon: LockClosedIcon, },
    {
      name: 'SSL certificates.',
      description: 'Anim aute id magna aliqua ad ad non deserunt sunt. Qui irure qui lorem cupidatat commodo.',
      icon: LockClosedIcon,
    },
    {
      name: 'Database backups.',
      description: 'Ac tincidunt sapien vehicula erat auctor pellentesque rhoncus. Et magna sit morbi lobortis.',
      icon: ServerIcon,
    },
    {
        name: 'Advanced security',
        description:
          'Arcu egestas dolor vel iaculis in ipsum mauris. Tincidunt mattis aliquet hac quis. Id hac maecenas ac donec pharetra eget.',
        icon: FingerPrintIcon,
      },
  ]

export default function Example() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const settings = {
    dots: true,
    infinite: true,
    autoplaySpeed: 3000, 
    autoplay: true,        // Enables auto sliding
  
  }

  return (
    <div>
            <div className="bg-white">
      <header className="absolute inset-x-0 top-0 z-50 fixed">
        <nav aria-label="Global" className="flex items-center justify-between p-6 lg:px-8">
          <div className="flex lg:flex-1">
            <a href="/" className="-m-1.5 p-1.5">
              <span className="sr-only">Your Company</span>
              <img src={Logo} className="h-32 w-auto " alt="Logo" />
            </a>
          </div>
          <div className="flex lg:hidden">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              className="-m-2.5 inline-flex items-center justify-center rounded-md p-2.5 text-white"
            >
              <span className="sr-only">Open main menu</span>
              <Bars3Icon aria-hidden="true" className="h-6 w-6" />
            </button>
          </div>
          <div className="hidden lg:flex lg:gap-x-12">
            {navigation.map((item) => (
              <a key={item.name} href={item.href} className="text-sm font-semibold leading-6 text-white">
                {item.name}
              </a>
            ))}
          </div>
          {/* <div className="hidden lg:flex lg:flex-1 lg:justify-end">
            <a href="/Product" className="text-sm font-semibold leading-6 text-white">
              Log in <span aria-hidden="true">&rarr;</span>
            </a>
          </div> */}
        </nav>
        <Dialog open={mobileMenuOpen} onClose={setMobileMenuOpen} className="lg:hidden">
          <div className="fixed inset-0 z-50" />
          <DialogPanel className="fixed inset-y-0 right-0 z-50 w-full overflow-y-auto bg-white px-6 py-6 sm:max-w-sm sm:ring-1 sm:ring-gray-900/10">
            <div className="flex items-center justify-between">
              <a href="#" className="-m-1.5 p-1.5">
                <span className="sr-only">Your Company</span>
                <img src={Logo} className="h-32 w-auto rounded" alt="Logo" />
              </a>
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                className="-m-2.5 rounded-md p-2.5 text-gray-700"
              >
                <span className="sr-only">Close menu</span>
                <XMarkIcon aria-hidden="true" className="h-6 w-6" />
              </button>
            </div>
            <div className="mt-6 flow-root">
              <div className="-my-6 divide-y divide-gray-500/10">
                <div className="space-y-2 py-6">
                  {navigation.map((item) => (
                    <a
                      key={item.name}
                      href={item.href}
                      className="-mx-3 block rounded-lg px-3 py-2 text-base font-semibold leading-7 text-gray-900 hover:bg-gray-50"
                    >
                      {item.name}
                    </a>
                  ))}
                </div>
                <div className="py-6">
                  <a
                    href="/Product"
                    className="-mx-3 block rounded-lg px-3 py-2.5 text-base font-semibold leading-7 text-gray-900 hover:bg-gray-50"
                  >
                    Log in
                  </a>
                </div>
              </div>
            </div>
          </DialogPanel>
        </Dialog>
      </header>
   

      {/* <div className="relative isolate px-6  ">
        <div
          aria-hidden="true"
          className="absolute inset-x-0 -top-40 -z-10 transform-gpu overflow-hidden blur-3xl sm:-top-80"
        >
          <div
            style={{
              clipPath:
                'polygon(74.1% 44.1%, 100% 61.6%, 97.5% 26.9%, 85.5% 0.1%, 80.7% 2%, 72.5% 32.5%, 60.2% 62.4%, 52.4% 68.1%, 47.5% 58.3%, 45.2% 34.5%, 27.5% 76.7%, 0.1% 64.9%, 17.9% 100%, 27.6% 76.8%, 76.1% 97.7%, 74.1% 44.1%)',
            }}
            className="relative left-[calc(50%-11rem)] aspect-[1155/678] w-[36.125rem] -translate-x-1/2 rotate-[30deg] bg-gradient-to-tr from-[#f4700da8] to-[#e06200ab] opacity-30 sm:left-[calc(50%-30rem)] sm:w-[72.1875rem]"
          />
        </div>
        <div className="mx-auto max-w-2xl py-32 sm:py-48 lg:py-40">
          <div className="hidden sm:mb-8 sm:flex sm:justify-center">
            <div className="text-orange-400relative rounded-full px-3 py-1 text-sm leading-6 text-gray-600 ring-1 ring-gray-900/10 hover:ring-gray-900/20">
              Our E-commerce website is comming soon{' '}
             
            </div>
          </div>
          <div className="text-center">
            <h1 className="text-4xl font-bold tracking-tight text-gray-900 sm:text-6xl">
            Transform Your Living Space
            </h1>
            <p className="mt-6 text-lg leading-8 text-gray-600">
            Discover the perfect blend of modern house designs and innovative Japanese washlets. Our curated selections combine sophistication with advanced technology, ensuring that every detail enhances your lifestyle.
            </p>
            <div className="mt-10 flex items-center justify-center gap-x-6">
              <a
                href='/Product'
                className="rounded-md bg-orange-400 px-3.5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-orange-400 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-orange-400"
              >
               Explore our products
              </a>
           
            </div>
            
          </div>
          
        </div>
     
      </div> */}
      <div className="relative isolate px-6">
  {/* Background Video */}
  <img
    src="https://cdn.dribbble.com/users/3972488/screenshots/12575146/media/da38a56036cc17079dbbea6a4a969619.gif"
    alt="Background GIF"
    className="absolute inset-0 z-[-1] h-full w-screen object-cover"
  />
  
  {/* Background Gradient Element */}
  {/* <div
    aria-hidden="true"
    className="absolute inset-x-0 -top-40 -z-10 transform-gpu overflow-hidden blur-3xl sm:-top-80"
  >
    <div
      style={{
        clipPath:
          'polygon(74.1% 44.1%, 100% 61.6%, 97.5% 26.9%, 85.5% 0.1%, 80.7% 2%, 72.5% 32.5%, 60.2% 62.4%, 52.4% 68.1%, 47.5% 58.3%, 45.2% 34.5%, 27.5% 76.7%, 0.1% 64.9%, 17.9% 100%, 27.6% 76.8%, 76.1% 97.7%, 74.1% 44.1%)',
      }}
      className="relative left-[calc(50%-11rem)] aspect-[1155/678] w-[36.125rem] -translate-x-1/2 rotate-[30deg] bg-gradient-to-tr from-[#f4700da8] to-[#e06200ab] opacity-30 sm:left-[calc(50%-30rem)] sm:w-[72.1875rem]"
    />
  </div> */}

  {/* Content Section */}
  <div className="mx-auto max-w-2xl py-32 sm:py-48 lg:py-40">
    <div className="hidden sm:mb-8 sm:flex sm:justify-center">
      <div className="text-orange-400 relative rounded-full px-3 py-1 text-sm leading-6 text-gray-600 ring-1 ring-gray-900/10 hover:ring-gray-900/20">
        Our E-commerce website is coming soon
      </div>
    </div>
    <div className="text-center">
      <h1 className="text-4xl font-bold tracking-tight text-white sm:text-6xl">
        Transform Your Living Space
      </h1>
      <p className="mt-6 text-lg leading-8 text-white">
        Discover the perfect blend of modern house designs and innovative
        Japanese washlets. Our curated selections combine sophistication with
        advanced technology, ensuring that every detail enhances your lifestyle.
      </p>
      <div className="mt-10 flex items-center justify-center gap-x-6">
        <a
          href="/Product"
          className="rounded-md bg-orange-400 px-3.5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-orange-400 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-orange-400"
        >
          Explore our products
        </a>
      </div>
    </div>
  </div>
</div>

    </div>
    


    <div className="bg-white py-24 sm:py-20">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto max-w-2xl lg:text-center">
          {/* <h2 className="text-base font-semibold leading-7 text-orange-400">Deploy faster</h2> */}
          <p className="mt-2 text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">
            Everything you need to deploy your app
          </p>
          <p className="mt-6 text-lg leading-8 text-gray-600">
            Quis tellus eget adipiscing convallis sit sit eget aliquet quis. Suspendisse eget egestas a elementum
            pulvinar et feugiat blandit at. In mi viverra elit nunc.
          </p>
        </div>
        <div className="mx-auto mt-16 max-w-2xl sm:mt-20 lg:mt-24 lg:max-w-4xl">
          <dl className="grid max-w-xl grid-cols-1 gap-x-8 gap-y-10 lg:max-w-none lg:grid-cols-2 lg:gap-y-16">
            {features.map((feature) => (
              <div key={feature.name} className="relative pl-16">
                <dt className="text-base font-semibold leading-7 text-gray-900">
                  <div className="absolute left-0 top-0 flex h-10 w-10 items-center justify-center rounded-lg bg-orange-400">
                    <feature.icon aria-hidden="true" className="h-6 w-6 text-white" />
                  </div>
                  {feature.name}
                </dt>
                <dd className="mt-2 text-base leading-7 text-gray-600">{feature.description}</dd>
              </div>
            ))}
          </dl>
        </div>
      </div>
    </div>
    <div className="overflow-hidden bg-white sm:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto grid max-w-2xl grid-cols-1 gap-x-8 gap-y-16 sm:gap-y-20 lg:mx-0 lg:max-w-none lg:grid-cols-2">
          <div className="lg:pr-8 lg:pt-4">
            <div className="lg:max-w-lg">
              <h2 className="text-base font-semibold leading-7 text-orange-400">Deploy faster</h2>
              <p className="mt-2 text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">A better workflow</p>
              <p className="mt-6 text-lg leading-8 text-gray-600">
                Lorem ipsum, dolor sit amet consectetur adipisicing elit. Maiores impedit perferendis suscipit eaque,
                iste dolor cupiditate blanditiis ratione.
              </p>
              <dl className="mt-10 max-w-xl space-y-8 text-base leading-7 text-gray-600 lg:max-w-none">
                {features.map((feature) => (
                  <div key={feature.name} className="relative pl-9">
                    <dt className="inline font-semibold text-gray-900">
                      <feature.icon aria-hidden="true" className="absolute left-1 top-1 h-5 w-5 text-orange-400" />
                      {feature.name}
                    </dt>{' '}
                    <dd className="inline">{feature.description}</dd>
                  </div>
                ))}
              </dl>
            </div>
          </div>

          {/* Carousel with hover zoom effect */}
          <Slider {...settings} className="lg:ml-10">
            <div className="group relative" >
              <img style={{height:'600px', width: '1000px'}}
                alt="Product screenshot 1"
                src={productImage}
                
                
                className="w-[48rem] max-w-none rounded-xl shadow-xl ring-1 ring-gray-400/10 sm:w-[57rem] md:-ml-4 lg:-ml-0 transition-transform duration-300 group-hover:scale-105"
              />
            </div>
            <div className="group relative">
              <img style={{height:'600px', width: '1000px'}}
                alt="Product screenshot 2"
                src={productImage1}
                
                
                className="w-[48rem] max-w-none rounded-xl shadow-xl ring-1 ring-gray-400/10 sm:w-[57rem] md:-ml-4 lg:-ml-0 transition-transform duration-300 group-hover:scale-105"
              />
            </div>
            <div className="group relative">
              <img style={{height:'600px', width: '1000px'}}
                alt="Product screenshot 2"
                src={productImage2}
                
                
                className="w-[48rem] max-w-none rounded-xl shadow-xl ring-1 ring-gray-400/10 sm:w-[57rem] md:-ml-4 lg:-ml-0 transition-transform duration-300 group-hover:scale-105"
              />
            </div>
            {/* Add more images if needed */}
          </Slider>
        </div>
      </div>
    </div>
         {/* <div className="bg-white py-24 sm:py-2">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="mx-auto max-w-2xl lg:text-center">
            <p className="mt-2 text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">
              Everything You Need to Elevate Your Space
            </p>
            <p className="mt-6 text-lg leading-8 text-gray-600">
              From modern home designs to innovative bathroom solutions, we provide comprehensive options to transform your living environment with style and functionality.
            </p>
         
       
        </div>
      </div>
    </div> */}

{/* <div className="bg-gray-50 py-24 sm:py-8">
  <div className="mx-auto max-w-7xl px-6 lg:px-8">
    <div className="mx-auto max-w-2xl lg:text-center">
      <h1 className="text-base font-semibold leading-7 text-orange-400">Our Magic Process</h1>
      <p className="mt-2 text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">
        Seamless Design & Integration
      </p>
      <p className="mt-6 text-lg leading-8 text-gray-600">
        We prioritize your satisfaction through our efficient, end-to-end process that ensures every project is delivered to the highest standards.
      </p>
    </div>

    <div className="mt-16 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-12">
      <div className="flex flex-col items-center rounded-lg bg-white shadow-lg p-6 transition hover:scale-105">
        <div className="h-12 w-12 flex items-center justify-center rounded-full bg-orange-400 text-white">
          <CalendarIcon className="h-6 w-6" aria-hidden="true" />
        </div>
        <h3 className="mt-6 text-lg font-semibold leading-8 text-gray-900 text-center">Planning & Consultation</h3>
        <p className="mt-2 text-base leading-7 text-gray-600 text-center">
          We work closely with you to understand your needs and design preferences, ensuring a custom solution that fits your lifestyle.
        </p>
      </div>

      <div className="flex flex-col items-center rounded-lg bg-white shadow-lg p-6 transition hover:scale-105">
        <div className="h-12 w-12 flex items-center justify-center rounded-full bg-orange-400 text-white">
          <HomeModernIcon className="h-6 w-6" aria-hidden="true" />
        </div>
        <h3 className="mt-6 text-lg font-semibold leading-8 text-gray-900 text-center">Design & Development</h3>
        <p className="mt-2 text-base leading-7 text-gray-600 text-center">
          Our team of experts crafts modern home designs and bathroom solutions that integrate the latest technology and materials for optimal results.
        </p>
      </div>

      <div className="flex flex-col items-center rounded-lg bg-white shadow-lg p-6 transition hover:scale-105">
        <div className="h-12 w-12 flex items-center justify-center rounded-full bg-orange-400 text-white">
          <LightBulbIcon className="h-6 w-6" aria-hidden="true" />
        </div>
        <h3 className="mt-6 text-lg font-semibold leading-8 text-gray-900 text-center">Installation & Finishing</h3>
        <p className="mt-2 text-base leading-7 text-gray-600 text-center">
          Our skilled team ensures that your new space is installed to perfection, blending functionality and style for a finished product you'll love.
        </p>
      </div>
    </div>
  </div>
</div> */}

<section className="relative  pb-24 bg-white overflow-hidden">

  <div className="relative z-10 container px-4 mx-auto">
<div className="relative">
      <HeroVideoDialog
        className="dark:hidden block"
        animationStyle="top-in-bottom-out"
        videoSrc="https://www.youtube.com/embed/qh3NGpYRG3I?si=4rb-zSdDkVK9qxxb"
        thumbnailSrc="https://startup-template-sage.vercel.app/hero-light.png"
        thumbnailAlt="Hero Video"
      />

    </div>
    </div>
    </section>


<section className="relative pt-12 pb-24 bg-white overflow-hidden">

  <div className="relative z-10 container px-4 mx-auto">
    <p className="mb-6 text-sm text-orange-400 text-center font-semibold uppercase tracking-px">How Flaro works</p>
    <h2 className="mb-20 text-6xl md:text-3xl text-center font-bold font-heading tracking-px-n leading-tight">Make things easy for your business</h2>
    <div className="flex flex-wrap -m-8">
      <div className="w-full md:w-1/2 lg:w-1/4 p-8">
        <div className="text-center">
          <div className="relative z-10 bg-white w-12 h-12 mb-8 mx-auto border border-blueGray-200 rounded-full">
            <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2">
              <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M2.75 9.16658H19.25M6.41667 13.7499H7.33333M11 13.7499H11.9167M5.5 17.4166H16.5C18.0188 17.4166 19.25 16.1854 19.25 14.6666V7.33325C19.25 5.81447 18.0188 4.58325 16.5 4.58325H5.5C3.98122 4.58325 2.75 5.81447 2.75 7.33325V14.6666C2.75 16.1854 3.98122 17.4166 5.5 17.4166Z" stroke="rgb(251 146 60)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
              </svg>
            </div>
            <div className="hidden lg:block absolute left-12 top-1/2 transform -translate-y-1/2 w-96 h-px bg-gray-200"></div>
          </div>
          <div className="md:max-w-xs mx-auto">
            <h3 className="mb-4 font-heading text-xl font-bold font-heading leading-normal">Choose a Plan</h3>
            <p className="text-gray-600 font-medium leading-relaxed">Lorem ipsum dolor sit amet consectetur adipiscing elit. Volutpat tempor con.</p>
          </div>
        </div>
      </div>
      <div className="w-full md:w-1/2 lg:w-1/4 p-8">
        <div className="text-center">
          <div className="relative z-10 bg-white w-12 h-12 mb-8 mx-auto border border-blueGray-200 rounded-full">
            <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M16 8V16M12 11V16M8 14V16M6 20H18C19.1046 20 20 19.1046 20 18V6C20 4.89543 19.1046 4 18 4H6C4.89543 4 4 4.89543 4 6V18C4 19.1046 4.89543 20 6 20Z" stroke="rgb(251 146 60)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
              </svg>
            </div>
            <div className="hidden lg:block absolute left-12 top-1/2 transform -translate-y-1/2 w-96 h-px bg-gray-200"></div>
          </div>
          <div className="md:max-w-xs mx-auto">
            <h3 className="mb-4 font-heading text-xl font-bold font-heading leading-normal">Answer Basic Questions</h3>
            <p className="text-gray-600 font-medium leading-relaxed">Lorem ipsum dolor sit amet consectetur adipiscing elit. Volutpat tempor con.</p>
          </div>
        </div>
      </div>
      <div className="w-full md:w-1/2 lg:w-1/4 p-8">
        <div className="text-center">
          <div className="relative z-10 bg-white w-12 h-12 mb-8 mx-auto border border-blueGray-200 rounded-full">
            <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2">
              <svg width="19" height="16" viewBox="0 0 19 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M8.66717 2.54545V10.0455C8.66717 10.7841 8.52335 11.489 8.23571 12.1602C7.94807 12.8313 7.55922 13.4119 7.06916 13.902C6.5791 14.392 5.99849 14.7809 5.32733 15.0685C4.65616 15.3562 3.95126 15.5 3.21262 15.5H2.53081C2.34615 15.5 2.18635 15.4325 2.0514 15.2976C1.91646 15.1626 1.84899 15.0028 1.84899 14.8182V13.4545C1.84899 13.2699 1.91646 13.1101 2.0514 12.9751C2.18635 12.8402 2.34615 12.7727 2.53081 12.7727H3.21262C3.96547 12.7727 4.60822 12.5064 5.14089 11.9737C5.67356 11.4411 5.9399 10.7983 5.9399 10.0455V9.70455C5.9399 9.42046 5.84047 9.17898 5.6416 8.98011C5.44274 8.78125 5.20126 8.68182 4.91717 8.68182H2.53081C1.96262 8.68182 1.47967 8.48295 1.08194 8.08523C0.684215 7.6875 0.485352 7.20455 0.485352 6.63636V2.54545C0.485352 1.97727 0.684215 1.49432 1.08194 1.09659C1.47967 0.698864 1.96262 0.5 2.53081 0.5H6.62172C7.1899 0.5 7.67285 0.698864 8.07058 1.09659C8.46831 1.49432 8.66717 1.97727 8.66717 2.54545ZM18.2126 2.54545V10.0455C18.2126 10.7841 18.0688 11.489 17.7812 12.1602C17.4935 12.8313 17.1047 13.4119 16.6146 13.902C16.1246 14.392 15.5439 14.7809 14.8728 15.0685C14.2016 15.3562 13.4967 15.5 12.7581 15.5H12.0763C11.8916 15.5 11.7318 15.4325 11.5969 15.2976C11.4619 15.1626 11.3944 15.0028 11.3944 14.8182V13.4545C11.3944 13.2699 11.4619 13.1101 11.5969 12.9751C11.7318 12.8402 11.8916 12.7727 12.0763 12.7727H12.7581C13.5109 12.7727 14.1537 12.5064 14.6863 11.9737C15.219 11.4411 15.4854 10.7983 15.4854 10.0455V9.70455C15.4854 9.42046 15.3859 9.17898 15.1871 8.98011C14.9882 8.78125 14.7467 8.68182 14.4626 8.68182H12.0763C11.5081 8.68182 11.0251 8.48295 10.6274 8.08523C10.2297 7.6875 10.0308 7.20455 10.0308 6.63636V2.54545C10.0308 1.97727 10.2297 1.49432 10.6274 1.09659C11.0251 0.698864 11.5081 0.5 12.0763 0.5H16.1672C16.7354 0.5 17.2183 0.698864 17.616 1.09659C18.0138 1.49432 18.2126 1.97727 18.2126 2.54545Z" fill="rgb(251 146 60)"></path>
              </svg>
            </div>
            <div className="hidden lg:block absolute left-12 top-1/2 transform -translate-y-1/2 w-96 h-px bg-gray-200"></div>
          </div>
          <div className="md:max-w-xs mx-auto">
            <h3 className="mb-4 font-heading text-xl font-bold font-heading leading-normal">Get a Quotation</h3>
            <p className="text-gray-600 font-medium leading-relaxed">Lorem ipsum dolor sit amet consectetur adipiscing elit. Volutpat tempor con.</p>
          </div>
        </div>
      </div>
      <div className="w-full md:w-1/2 lg:w-1/4 p-8">
        <div className="text-center">
          <div className="relative z-10 bg-orange-400 w-12 h-12 mb-8 mx-auto border border-blueGray-200 rounded-full">
            <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2">
              <svg width="22" height="16" viewBox="0 0 22 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M20.5734 0.93934C21.1591 1.52513 21.1591 2.47487 20.5734 3.06066L8.57336 15.0607C7.98757 15.6464 7.03782 15.6464 6.45204 15.0607L0.452035 9.06066C-0.133751 8.47487 -0.133751 7.52513 0.452035 6.93934C1.03782 6.35355 1.98757 6.35355 2.57336 6.93934L7.5127 11.8787L18.452 0.93934C19.0378 0.353553 19.9876 0.353553 20.5734 0.93934Z" fill="white" ></path>
              </svg>
            </div>
          </div>
          <div className="md:max-w-xs mx-auto">
            <h3 className="mb-4 font-heading text-xl font-bold font-heading leading-normal">Get Covered</h3>
            <p className="text-gray-600 font-medium leading-relaxed">Lorem ipsum dolor sit amet consectetur adipiscing elit. Volutpat tempor con.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<Footer1/>

    </div>

    
  )
}
