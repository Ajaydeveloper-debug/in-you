import { Dialog, DialogPanel } from '@headlessui/react'
import { Bars3Icon, XMarkIcon } from '@heroicons/react/24/outline'
import { useState } from 'react'
import Logo from '../assets/images/ダウンロード-removebg-preview.png';
import Footer1 from '../components/Footer'

const navigation = [
  { name: 'Home', href: '/' },
  { name: 'About', href: '/About' },
  { name: 'Our Products', href: '/Product' },
  { name: 'Architecture designs', href: '#' },
  { name: 'Contact', href: '#' },
]

const AboutUsSection = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  return (
 
    <section className="">
   <header className="absolute inset-x-0 top-0 z-50 fixed">
        <nav aria-label="Global" className="flex items-center justify-between p-6 lg:px-8">
          <div className="flex lg:flex-1">
            <a href="/" className="-m-1.5 p-1.5">
              <span className="sr-only">Your Company</span>
              <img src={Logo} className="h-32 w-auto rounded" alt="Logo" />
            </a>
          </div>
          <div className="flex lg:hidden">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              className="-m-2.5 inline-flex items-center justify-center rounded-md p-2.5"
            >
              <span className="sr-only">Open main menu</span>
              <Bars3Icon aria-hidden="true" className="h-6 w-6" />
            </button>
          </div>
          <div className="hidden lg:flex lg:gap-x-12">
            {navigation.map((item) => (
              <a key={item.name} href={item.href} className="text-sm font-semibold leading-6">
                {item.name}
              </a>
            ))}
          </div>
          {/* <div className="hidden lg:flex lg:flex-1 lg:justify-end">
            <a href="/Product" className="text-sm font-semibold leading-6">
              Log in <span aria-hidden="true">&rarr;</span>
            </a>
          </div> */}
        </nav>
        <Dialog open={mobileMenuOpen} onClose={setMobileMenuOpen} className="lg:hidden">
          <div className="fixed inset-0 z-50" />
          <DialogPanel className="fixed inset-y-0 right-0 z-50 w-full overflow-y-auto bg-white px-6 py-6 sm:max-w-sm sm:ring-1 sm:ring-gray-900/10">
            <div className="flex items-center justify-between">
              <a href="/"className="-m-1.5 p-1.5">
                <span className="sr-only">Your Company</span>
                <img src={Logo} className="h-32 w-auto rounded" alt="Logo" />
              </a>
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                className="-m-2.5 rounded-md p-2.5 text-gray-700"
              >
                <span className="sr-only">Close menu</span>
                <XMarkIcon aria-hidden="true" className="h-6 w-6" />
              </button>
            </div>
            <div className="mt-6 flow-root">
              <div className="-my-6 divide-y divide-gray-500/10">
                <div className="space-y-2 py-6">
                  {navigation.map((item) => (
                    <a
                      key={item.name}
                      href={item.href}
                      className="-mx-3 block rounded-lg px-3 py-2 text-base font-semibold leading-7 text-gray-900 hover:bg-gray-50"
                    >
                      {item.name}
                    </a>
                  ))}
                </div>
                <div className="py-6">
                  <a
                    href="/Product"
                    className="-mx-3 block rounded-lg px-3 py-2.5 text-base font-semibold leading-7 text-gray-900 hover:bg-gray-50"
                  >
                    Log in
                  </a>
                </div>
              </div>
            </div>
          </DialogPanel>
        </Dialog>
      </header>
      <div className="container-fluid px-12 mx-auto pt-24">
        <div className="flex flex-wrap mb-32 mt-16 -mx-8">
          <div className="w-full lg:w-1/2 px-8">
            <div className="flex items-center justify-between flex-wrap gap-4 mb-4">
              <div className="py-1 px-3 rounded-lg border border-orange-100 bg-orange-50 flex items-center gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" width="8" height="8" viewBox="0 0 8 8" fill="none">
                  <circle cx="4" cy="4" r="3" fill="#FF7100"></circle>
                </svg>
                <span className="text-orange-500 text-sm font-medium">About Us</span>
              </div>
          
            </div>
            <img  className="rounded-3xl w-full mb-8" src="https://img.freepik.com/free-photo/people-business-meeting-high-angle_23-2148911819.jpg?t=st=1726616343~exp=1726619943~hmac=c2ceb0f4ba3728d39f284cde09b8e997ab0cca709b5d830f295de25efa44ebd3&w=900" alt="" />
          </div>
          <div className="w-full lg:w-1/2 px-8">
            <h1 className="text-5xl lg:text-7xl font-bold font-heading mb-10 max-w-xs lg:max-w-lg">
              On a mission to make learning fun
            </h1>
            <p className="text-gray-600 text-lg">
              We are driven to transform the landscape of learning into a captivating journey of excitement and
              discovery. Our aim is to infuse every educational experience with the essence of joy, making learning an
              immersive adventure that fuels curiosity and fosters growth.
            </p>
          </div>
        </div>
        <div className="border border-gray-200 bg-white rounded-3xl flex flex-wrap mb-32">
          <div className="w-full md:w-1/2 lg:w-1/4 py-8">
            <div className="md:border-r border-gray-200 px-12">
              <p className="text-gray-600 mb-2 text-center">Founded</p>
              <h2 className="text-4xl lg:text-5xl font-semibold text-center">2023</h2>
            </div>
          </div>
          <div className="w-full md:w-1/2 lg:w-1/4 py-8">
            <div className="lg:border-r border-gray-200 px-12">
              <p className="text-gray-600 mb-2 text-center">Total funding</p>
              <h2 className="text-4xl lg:text-5xl font-semibold text-center">$9.6M</h2>
            </div>
          </div>
          <div className="w-full md:w-1/2 lg:w-1/4 py-8">
            <div className="md:border-r border-gray-200 px-12">
              <p className="text-gray-600 mb-2 text-center">Team members</p>
              <h2 className="text-4xl lg:text-5xl font-semibold text-center">110</h2>
            </div>
          </div>
          <div className="w-full md:w-1/2 lg:w-1/4 py-8">
            <div className="px-12">
              <p className="text-gray-600 mb-2 text-center">Nationalities</p>
              <h2 className="text-4xl lg:text-5xl font-semibold text-center">24</h2>
            </div>
          </div>
        </div>
        <div className="flex flex-wrap mb-32 -mx-8">
          <div className="w-full lg:w-1/2 px-8">
            <h2 className="text-3xl lg:text-5xl font-bold font-heading mb-20 max-w-xs lg:max-w-lg">
              A company with values
            </h2>
            <img className="rounded-3xl w-full mb-8" src="https://img.freepik.com/premium-photo/female-manager-using-whiteboard-meeting-elevated-view_625516-3460.jpg?w=900" alt="class" />
            <img className="rounded-3xl w-full mb-8" src="https://img.freepik.com/premium-photo/team-mature-lady-african-american-woman-dressmakers-with-drawing-light-fashion-studio-upper-view_386167-14276.jpg?w=900" alt="" />
          </div>
          <div className="w-full lg:w-1/2 px-8">
            <img className="rounded-3xl w-full mb-24" src="https://img.freepik.com/free-photo/people-studying-cafeteria_23-2147679037.jpg?t=st=1726566042~exp=1726569642~hmac=b5efe14d24bb033a79740634a38b67e8704557da377898b7742a9a854d8077d0&w=900" alt="" />
            <p className="text-gray-600 text-lg mb-10">
              Diversity, inclusion, and belonging are fundamental to our success. We believe the best solutions occur
              when a plurality of backgrounds, experiences, and identities work together.
            </p>
            <p className="text-gray-600 text-lg">
              All your operations are connected in a single platform, transforming work into a visible, automated, and
              collaborative experience. At every turn, you’re supported by smart suggestions and interventions that
              understand your business and anticipate your needs.
            </p>
          </div>
        </div>
        <h2 className="text-center text-4xl lg:text-5xl mb-9 font-bold font-heading">Our investors</h2>
        <div className="bg-gray-50 rounded-3xl mb-32 flex flex-wrap py-8">
          <div className="w-full md:w-1/2 lg:w-1/3 py-8 px-16 flex justify-center items-center">
            <img src="solstice-assets/images/logos/placeholder-logo1.png" alt="" />
          </div>
          <div className="w-full md:w-1/2 lg:w-1/3 py-8 px-16 flex justify-center items-center">
            <img src="solstice-assets/images/logos/placeholder-logo2.png" alt="" />
          </div>
          <div className="w-full md:w-1/2 lg:w-1/3 py-8 px-16 flex justify-center items-center">
            <img src="solstice-assets/images/logos/placeholder-logo3.png" alt="" />
          </div>
          <div className="w-full md:w-1/2 lg:w-1/3 py-8 px-16 flex justify-center items-center">
            <img src="solstice-assets/images/logos/placeholder-logo4.png" alt="" />
          </div>
          <div className="w-full md:w-1/2 lg:w-1/3 py-8 px-16 flex justify-center items-center">
            <img src="solstice-assets/images/logos/placeholder-logo5.png" alt="" />
          </div>
          <div className="w-full md:w-1/2 lg:w-1/3 py-8 px-16 flex justify-center items-center">
            <img src="solstice-assets/images/logos/placeholder-logo6.png" alt="" />
          </div>
        </div>
        <div className="bg-orange-50 rounded-3xl pt-24 pb-16 px-8 overflow-hidden mb-24 relative">
  <h2 className="text-4xl font-bold font-heading text-center mb-4">Meet the team</h2>
  <p className="text-center text-gray-600 mb-12">
    A dynamic group of individuals united by passion and expertise
  </p>
  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
    <div className="relative bg-no-repeat bg-cover rounded-3xl w-full" style={{ height: '250px', backgroundImage: "url('https://img.freepik.com/free-photo/image-smiling-asian-woman-planning-thinking-smth-daydreaming-standing-white-background-with-smug-face_1258-89404.jpg')" }}>
      <div className="absolute bottom-0 left-0 bg-orange-50 rounded-tr-3xl rounded-bl-3xl px-6 py-3">
        <h2 className="text-2xl font-bold font-heading mb-2">David Petrucci</h2>
        <p className="text-sm text-gray-600">Founder & CEO</p>
      </div>
    </div>

    <div className="relative bg-no-repeat bg-cover rounded-3xl w-full" style={{ height: '250px', backgroundImage: "url('https://img.freepik.com/free-photo/young-woman-posing-outdoor-field_23-2149334480.jpg?t=st=1726728138~exp=1726731738~hmac=e42325d99d1e73c13d50981f22da869985bdb437e5a88a1d5b92549fb9d8bc33&w=900')" }}>
      <div className="absolute bottom-0 left-0 bg-orange-50 rounded-tr-3xl rounded-bl-3xl px-6 py-3">
        <h2 className="text-2xl font-bold font-heading mb-2">Erika Newton</h2>
        <p className="text-sm text-gray-600">Growth Marketer</p>
      </div>
    </div>

    <div className="relative bg-no-repeat bg-cover rounded-3xl w-full" style={{ height: '250px', backgroundImage: "url('https://img.freepik.com/free-photo/smiling-portrait-candid-laughing-woman-beach_285396-6719.jpg?t=st=1726728199~exp=1726731799~hmac=eaac4d9f4d78a2fba13c7ca926044f223444dc7c33a51e832c86b48881d558e6&w=900')" }}>
      <div className="absolute bottom-0 left-0 bg-orange-50 rounded-tr-3xl rounded-bl-3xl px-6 py-3">
        <h2 className="text-2xl font-bold font-heading mb-2">Malika Gil</h2>
        <p className="text-sm text-gray-600">Operations Manager</p>
      </div>
    </div>
    <div className="relative bg-no-repeat bg-cover rounded-3xl w-full" style={{ height: '250px', backgroundImage: "url('https://img.freepik.com/free-photo/cool-chinese-woman-thinking_1149-1894.jpg?t=st=1726728221~exp=1726731821~hmac=dc63a5fb0b37c688e1d871029ba051869c1682fcf16f0054940caf8fb4e04ab3&w=740')" }}>
      <div className="absolute bottom-0 left-0 bg-orange-50 rounded-tr-3xl rounded-bl-3xl px-6 py-3">
        <h2 className="text-2xl font-bold font-heading mb-2">Malika Gil</h2>
        <p className="text-sm text-gray-600">Operations Manager</p>
      </div>
    </div>
    <div className="relative bg-no-repeat bg-cover rounded-3xl w-full" style={{ height: '250px', backgroundImage: "url('https://img.freepik.com/premium-photo/portrait-beautiful-girl-paris-france_599991-1739.jpg?w=900')" }}>
      <div className="absolute bottom-0 left-0 bg-orange-50 rounded-tr-3xl rounded-bl-3xl px-6 py-3">
        <h2 className="text-2xl font-bold font-heading mb-2">Malika Gil</h2>
        <p className="text-sm text-gray-600">Operations Manager</p>
      </div>
    </div>
    <div className="relative bg-no-repeat bg-cover rounded-3xl w-full" style={{ height: '250px', backgroundImage: "url('https://img.freepik.com/free-photo/front-view-smiley-woman-seaside_23-2149455861.jpg?t=st=1726728322~exp=1726731922~hmac=80738f7feb0ac001e2c938a5691918a173d18fd47ee2664979b74b2016c7b591&w=900')" }}>
      <div className="absolute bottom-0 left-0 bg-orange-50 rounded-tr-3xl rounded-bl-3xl px-6 py-3">
        <h2 className="text-2xl font-bold font-heading mb-2">Malika Gil</h2>
        <p className="text-sm text-gray-600">Operations Manager</p>
      </div>
    </div>



    {/* Add more team members as needed, each inside a <div> like above */}
  </div>
</div>

      </div>
      <Footer1/>
      </section>
   
)
}
export default AboutUsSection;
